"use strict";exports.id=554,exports.ids=[554],exports.modules={80554:(e,r,n)=>{function s(e,r="#2FB190"){return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <!-- Header -->
      <div style="background: linear-gradient(135deg, ${r} 0%, #18223b 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">
          💡 Ani<span style="color: #FFDE59;">RESERVE</span>
        </h1>
        <p style="color: rgba(255,255,255,0.9); margin: 5px 0 0 0; font-size: 14px;">
          La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais
        </p>
      </div>
      
      <!-- Content -->
      <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none;">
        ${e}
      </div>
      
      <!-- Footer -->
      <div style="background: #f9fafb; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; border: 1px solid #e5e7eb; border-top: none;">
        <p style="color: #6b7280; font-size: 12px; margin: 0;">
          AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais<br>
          <a href="https://anireserve.com" style="color: ${r}; text-decoration: none;">anireserve.com</a> | 
          <a href="mailto:contact@anireserve.com" style="color: ${r}; text-decoration: none;">contact@anireserve.com</a>
        </p>
        <p style="color: #9ca3af; font-size: 11px; margin: 10px 0 0 0;">
          Vous recevez cet email car vous \xeates inscrit sur AniReserve
        </p>
      </div>
    </body>
    </html>
  `}function o(e){let r=`
    <h2 style="color: #2FB190; margin-top: 0;">🔔 Nouvelle inscription professionnel</h2>
    <p>Bonjour,</p>
    <p>Un nouveau professionnel vient de s'inscrire sur AniReserve et son dossier est en attente de validation.</p>
    
    <div style="background: #f0f9f7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2FB190;">
      <h3 style="margin-top: 0; color: #18223b;">Informations du professionnel</h3>
      <p style="margin: 5px 0;"><strong>👤 Nom :</strong> ${e.professionalName}</p>
      <p style="margin: 5px 0;"><strong>📧 Email :</strong> ${e.email}</p>
      ${e.phone?`<p style="margin: 5px 0;"><strong>📱 T\xe9l\xe9phone :</strong> ${e.phone}</p>`:""}
      <p style="margin: 5px 0;"><strong>📍 Ville :</strong> ${e.city}</p>
      <p style="margin: 5px 0;"><strong>💼 Service :</strong> ${e.serviceType}</p>
      ${e.description?`<p style="margin: 5px 0;"><strong>📝 Description :</strong> ${e.description}</p>`:""}
    </div>
    
    <p><strong>⏳ Action requise :</strong> Connectez-vous \xe0 l'espace admin pour valider ou rejeter ce profil.</p>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="${process.env.NEXT_PUBLIC_BASE_URL||"https://anireserve.com"}/admin/professionals/pending" 
         style="background: #2FB190; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">
        Acc\xe9der \xe0 l'espace admin
      </a>
    </div>
  `;return{subject:`🔔 Nouvelle inscription professionnel : ${e.professionalName}`,html:s(r,"#2FB190")}}function t(e){return{subject:"✅ Votre inscription AniReserve est en cours de traitement",html:s(`
    <h2 style="color: #2FB190; margin-top: 0;">✅ Inscription re\xe7ue !</h2>
    <p>Bonjour ${e.professionalName},</p>
    <p>Nous avons bien re\xe7u votre demande d'inscription sur <strong>AniReserve</strong>.</p>
    
    <div style="background: #f0f9f7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2FB190;">
      <p style="margin: 0;"><strong>⏳ Statut :</strong> Votre dossier est en cours de traitement</p>
      <p style="margin: 10px 0 0 0;">Notre \xe9quipe examine votre profil et vos documents. Vous recevrez un email d\xe8s que votre compte sera valid\xe9.</p>
    </div>
    
    <p><strong>📋 Prochaines \xe9tapes :</strong></p>
    <ul style="line-height: 1.8;">
      <li>V\xe9rification de vos documents (Teoudate Zeoute)</li>
      <li>Validation de votre profil professionnel</li>
      <li>Activation de votre compte</li>
    </ul>
    
    <p><strong>⏰ D\xe9lai de traitement :</strong> G\xe9n\xe9ralement sous 24-48 heures</p>
    
    <p>Une fois votre compte valid\xe9, vous pourrez :</p>
    <ul style="line-height: 1.8;">
      <li>G\xe9rer votre planning de disponibilit\xe9s</li>
      <li>Recevoir des demandes de r\xe9servation</li>
      <li>Appara\xeetre dans les r\xe9sultats de recherche</li>
    </ul>
    
    <p>En cas de question, n'h\xe9sitez pas \xe0 nous contacter \xe0 <a href="mailto:contact@anireserve.com" style="color: #2FB190;">contact@anireserve.com</a></p>
  `,"#2FB190")}}n.d(r,{sendBookingCancelledEmailToClient:()=>u,sendBookingCancelledEmailToPro:()=>m,sendBookingConfirmationEmail:()=>l,sendBookingConfirmedEmailToPro:()=>c,sn:()=>d,sendBookingRequestEmailToClient:()=>a,sendBookingRequestEmailToPro:()=>p,_M:()=>h,hA:()=>f,J1:()=>x,Ad:()=>v,Gq:()=>y});let i=new(n(5649)).u(process.env.RESEND_API_KEY||"re_YaufuMTW_LVJ8N4CdbffuSEVU6B1EYMrx");async function a(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Demande de r\xe9servation envoy\xe9e au client",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`Demande de r\xe9servation avec ${n}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #7c3aed;">📅 Demande de r\xe9servation</h1>
          <p>Bonjour ${r},</p>
          <p>Votre demande de r\xe9servation avec <strong>${n}</strong> a \xe9t\xe9 envoy\xe9e avec succ\xe8s.</p>
          <div style="background: #faf5ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #7c3aed;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${s}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>👤 Professionnel :</strong> ${n}</p>
          </div>
          <p><strong>⏳ Statut :</strong> En attente de confirmation par le professionnel</p>
          <p>Le professionnel va examiner votre demande et vous confirmera rapidement. Vous recevrez un email d\xe8s qu'il aura valid\xe9 votre r\xe9servation.</p>
          <p><strong>💳 Important :</strong> Le paiement se fera sur place au moment de la prestation.</p>
          <p>\xc0 bient\xf4t !</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function p(e,r,n,s,o,t){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Nouvelle demande de r\xe9servation envoy\xe9e au pro",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`Nouvelle demande de r\xe9servation de ${n}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ec4899;">✨ Nouvelle demande de r\xe9servation</h1>
          <p>Bonjour ${r},</p>
          <p>Vous avez re\xe7u une nouvelle demande de r\xe9servation de <strong>${n}</strong>.</p>
          <div style="background: #fdf2f8; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ec4899;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${t}</p>
            <p style="margin: 5px 0;"><strong>👤 Client :</strong> ${n}</p>
            <p style="margin: 5px 0;"><strong>📧 Email client :</strong> ${s}</p>
          </div>
          <p><strong>⏳ Action requise :</strong> Connectez-vous \xe0 votre espace professionnel pour valider ou refuser cette r\xe9servation.</p>
          <p style="margin-top: 20px;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL||"http://localhost:3000"}/pro/dashboard" 
               style="background: #ec4899; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
              Acc\xe9der \xe0 mon espace pro
            </a>
          </p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function l(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Confirmation de r\xe9servation envoy\xe9e au client",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`✅ R\xe9servation confirm\xe9e avec ${n}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #10b981;">✅ R\xe9servation confirm\xe9e !</h1>
          <p>Bonjour ${r},</p>
          <p>Excellente nouvelle ! Votre r\xe9servation avec <strong>${n}</strong> a \xe9t\xe9 confirm\xe9e.</p>
          <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${s}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>👤 Professionnel :</strong> ${n}</p>
          </div>
          <p><strong>💳 Important :</strong> Le paiement se fera sur place au moment de la prestation.</p>
          <p>Nous vous attendons avec impatience !</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function c(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Confirmation envoy\xe9e au pro",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`R\xe9servation confirm\xe9e : ${n} le ${s}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #10b981;">✅ R\xe9servation confirm\xe9e</h1>
          <p>Bonjour ${r},</p>
          <p>Vous avez confirm\xe9 la r\xe9servation de <strong>${n}</strong>.</p>
          <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${s}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>👤 Client :</strong> ${n}</p>
          </div>
          <p>Le client a \xe9t\xe9 notifi\xe9 de la confirmation. N'oubliez pas de pr\xe9parer votre rendez-vous !</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function d(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Rappel de r\xe9servation envoy\xe9 \xe0",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`Rappel : Rendez-vous demain avec ${n}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #18181b;">Rappel de rendez-vous</h1>
          <p>Bonjour ${r},</p>
          <p>Ceci est un rappel pour votre rendez-vous avec <strong>${n}</strong>.</p>
          <div style="background: #f4f4f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Date :</strong> ${s}</p>
            <p><strong>Heure :</strong> ${o}</p>
          </div>
          <p>\xc0 demain !</p>
          <p style="color: #71717a; font-size: 12px;">AniReserve</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function u(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Annulation envoy\xe9e au client",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`❌ R\xe9servation annul\xe9e avec ${n}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ef4444;">❌ R\xe9servation annul\xe9e</h1>
          <p>Bonjour ${r},</p>
          <p>Votre r\xe9servation avec <strong>${n}</strong> a \xe9t\xe9 annul\xe9e.</p>
          <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ef4444;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${s}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>👤 Professionnel :</strong> ${n}</p>
          </div>
          <p>Vous pouvez r\xe9server un autre cr\xe9neau si vous le souhaitez.</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function m(e,r,n,s,o){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Annulation envoy\xe9e au pro",e),{success:!0,simulated:!0};return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:`R\xe9servation annul\xe9e : ${n} le ${s}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ef4444;">❌ R\xe9servation annul\xe9e</h1>
          <p>Bonjour ${r},</p>
          <p>La r\xe9servation de <strong>${n}</strong> a \xe9t\xe9 annul\xe9e.</p>
          <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ef4444;">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${s}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>👤 Client :</strong> ${n}</p>
          </div>
          <p>Ce cr\xe9neau est maintenant disponible pour d'autres r\xe9servations.</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function x(e,r,n){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - R\xe9initialisation mot de passe envoy\xe9e \xe0",e),{success:!0,simulated:!0};let s=`${process.env.NEXT_PUBLIC_BASE_URL||"http://localhost:3000"}/client/reset-password?token=${n}`;return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:"R\xe9initialisation de votre mot de passe",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #7c3aed;">🔐 R\xe9initialisation de mot de passe</h1>
          <p>Bonjour ${r},</p>
          <p>Vous avez demand\xe9 \xe0 r\xe9initialiser votre mot de passe.</p>
          <p style="margin: 30px 0;">
            <a href="${s}" 
               style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
              R\xe9initialiser mon mot de passe
            </a>
          </p>
          <p>Ce lien est valide pendant 1 heure.</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function v(e,r,n){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - R\xe9initialisation mot de passe pro envoy\xe9e \xe0",e),{success:!0,simulated:!0};let s=`${process.env.NEXT_PUBLIC_BASE_URL||"http://localhost:3000"}/pro/reset-password?token=${n}`;return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:"R\xe9initialisation de votre mot de passe professionnel",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ec4899;">🔐 R\xe9initialisation de mot de passe</h1>
          <p>Bonjour ${r},</p>
          <p>Vous avez demand\xe9 \xe0 r\xe9initialiser votre mot de passe professionnel.</p>
          <p style="margin: 30px 0;">
            <a href="${s}" 
               style="background: #ec4899; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
              R\xe9initialiser mon mot de passe
            </a>
          </p>
          <p>Ce lien est valide pendant 1 heure.</p>
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function g(e,r,n,s="AniReserve <noreply@anireserve.com>"){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log(`📧 Email (simul\xe9) envoy\xe9 \xe0 ${e}`,n),{success:!0,simulated:!0};let o=r(n);return await i.emails.send({from:s,to:e,subject:o.subject,html:o.html}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}async function f(e,r,n,s,t,i){return g("admin@anireserve.com",o,{professionalName:e,email:r,phone:n,city:s,serviceType:t,description:i})}async function y(e,r){return g(e,t,{professionalName:r})}async function h(e,r,n,s,o,t,a){try{if(!process.env.RESEND_API_KEY||"re_placeholder"===process.env.RESEND_API_KEY)return console.log("\uD83D\uDCE7 Email (simul\xe9) - Changement de statut envoy\xe9 \xe0",e),{success:!0,simulated:!0};let p="confirmed"===a,l=p?`✅ R\xe9servation confirm\xe9e avec ${n}`:`❌ R\xe9servation annul\xe9e avec ${n}`,c=p?"#10b981":"#ef4444";return await i.emails.send({from:"AniReserve <noreply@anireserve.com>",to:e,subject:l,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: ${c};">${p?"✅ R\xe9servation confirm\xe9e !":"❌ R\xe9servation annul\xe9e"}</h1>
          <p>Bonjour ${r},</p>
          <p>La r\xe9servation avec <strong>${n}</strong> a \xe9t\xe9 ${p?"confirm\xe9e":"annul\xe9e"}.</p>
          <div style="background: ${p?"#ecfdf5":"#fef2f2"}; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid ${c};">
            <p style="margin: 0;"><strong>📅 Date :</strong> ${o}</p>
            <p style="margin: 5px 0;"><strong>⏰ Heure :</strong> ${t}</p>
            <p style="margin: 5px 0;"><strong>👤 ${p?"Professionnel":"Client"} :</strong> ${p?n:s}</p>
          </div>
          ${p?"<p><strong>\uD83D\uDCB3 Important :</strong> Le paiement se fera sur place au moment de la prestation.</p>":"<p>Vous pouvez r\xe9server un autre cr\xe9neau si vous le souhaitez.</p>"}
          <p style="color: #71717a; font-size: 12px; margin-top: 30px;">AniReserve - La plateforme de r\xe9servation en Isra\xebl pour les Fran\xe7ais</p>
        </div>
      `}),{success:!0}}catch(e){return console.error("Erreur envoi email:",e),{success:!1,error:e}}}}};