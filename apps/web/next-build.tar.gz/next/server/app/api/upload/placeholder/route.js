(()=>{var e={};e.id=1923,e.ids=[1923],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},24466:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>l,serverHooks:()=>c,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>u});var s={};r.r(s),r.d(s,{GET:()=>p});var a=r(31271),o=r(91232),n=r(18079),i=r(61238);async function p(e){try{let{searchParams:t}=new URL(e.url),r=t.get("name")||"Document",s=t.get("id")||Date.now().toString(),a=`
      <svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <rect width="400" height="300" fill="#f3f4f6"/>
        <text x="200" y="120" font-family="Arial, sans-serif" font-size="16" fill="#6b7280" text-anchor="middle">
          📄 ${r}
        </text>
        <text x="200" y="150" font-family="Arial, sans-serif" font-size="12" fill="#9ca3af" text-anchor="middle">
          Document upload\xe9
        </text>
        <text x="200" y="170" font-family="Arial, sans-serif" font-size="10" fill="#d1d5db" text-anchor="middle">
          ID: ${s}
        </text>
      </svg>
    `;return new i.NextResponse(a,{headers:{"Content-Type":"image/svg+xml","Cache-Control":"public, max-age=3600"}})}catch{return i.NextResponse.json({error:"Erreur lors de la g\xe9n\xe9ration du placeholder"},{status:500})}}let l=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/upload/placeholder/route",pathname:"/api/upload/placeholder",filename:"route",bundlePath:"app/api/upload/placeholder/route"},resolvedPagePath:"/Users/macbookpro/Desktop/aniresa/AniReserve/apps/web/src/app/api/upload/placeholder/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:d,workUnitAsyncStorage:u,serverHooks:c}=l;function x(){return(0,n.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:u})}},87032:()=>{},80408:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[6207,8048],()=>r(24466));module.exports=s})();